local wibox = require('wibox')
local system = require('system')

local network = {}

local format = "☎ %s: %d ms"
local hosts = { "github.com", "195.24.232.203", "10.7.1.23", "10.108.5.254", "192.168.0.1" }
local labels = { "W", "W w/o DNS", "KPI", "VIII", "L" }

local function data_callback(w, data)
   for i = 1, #hosts do
      if data[hosts[i]].loss ~= 100 then
         w:set_markup(string.format(format, labels[i], data[hosts[i]].time))
         return
      end
   end
   w:set_markup("☎ OFF")
end

function network.new()
   local _widget = wibox.widget.textbox()
   _widget:set_markup("☎ OFF")

   system.network.hosts = hosts
   system.network.add_callback(function(data)
                                  data_callback(_widget, data)
                               end)
   system.network.init()

   return _widget
end

return setmetatable(network, { __call = function(_, ...) return network.new(...) end})
