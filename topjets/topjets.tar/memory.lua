local wibox = require('wibox')
local scheduler = require('scheduler')

-- Module topjets.cpu
local memory = {}

function memory.new()
   local _widget = wibox.widget.textbox()
   scheduler.register_recurring("memory_update", 10,
                                function() memory.update(_widget) end)
   return _widget
end

function memory.update(w)
   local _mem = { buf = {} }

   -- Get MEM info
   for line in io.lines("/proc/meminfo") do
      for k, v in string.gmatch(line, "([%a]+):[%s]+([%d]+).+") do
         if     k == "MemTotal"  then _mem.total = math.floor(v/1024)
         elseif k == "MemFree"   then _mem.buf.f = math.floor(v/1024)
         elseif k == "Buffers"   then _mem.buf.b = math.floor(v/1024)
         elseif k == "Cached"    then _mem.buf.c = math.floor(v/1024)
         end
      end
   end

   -- Calculate memory percentage
   _mem.free  = _mem.buf.f + _mem.buf.b + _mem.buf.c
   _mem.inuse = _mem.total - _mem.free
   _mem.usep  = math.floor(_mem.inuse / _mem.total * 100)

   w:set_markup(string.format("♻ %d%%", _mem.usep))
end

return setmetatable(memory, { __call = function(_, ...) return memory.new(...) end})
