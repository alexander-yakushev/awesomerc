--- Custom widget library for Awesome Windows Manager.
return
{
   cpu = require('topjets.cpu'),
   memory = require('topjets.memory'),
   volume = require('topjets.volume'),
   network = require('topjets.network'),
   battery = require('topjets.battery')
}
